package arrays;

public class ExArray1 {

	public static void main(String[] args) {
		

	}

}
