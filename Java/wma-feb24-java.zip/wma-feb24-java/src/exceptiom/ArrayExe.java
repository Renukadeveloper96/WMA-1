package exceptiom;

public class ArrayExe {

	public static void main(String[] args) {
	int[] arr=new int[6];//6-1=5
	
	
	arr[0]=20;
	arr[5]=40;
	System.out.println(arr[3]);
//	arr[6]=100;
	}

}
