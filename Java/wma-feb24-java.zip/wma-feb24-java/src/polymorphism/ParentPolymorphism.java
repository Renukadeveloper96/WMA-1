package polymorphism;

public class ParentPolymorphism {

	public void m1() {
		System.out.println("Parent");
	}
	
	public void m2() {
		System.out.println("parent m2 method");
	}
	
	public int add(int a,int b) {
		return a+b;
		
	}
	

}
