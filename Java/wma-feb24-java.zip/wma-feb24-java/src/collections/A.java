package collections;

public class A {

	public static void main(String[] args) {
//		int a=10;    
//		int c=30;
//		int d=40;

	}

}
