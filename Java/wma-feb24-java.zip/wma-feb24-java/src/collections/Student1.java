package collections;

public class Student1 {
	private String name;

	public Student1(String name) {
		this.name=name;
	}

	public static void main(String[] args) {
		Student1 s[]=new Student1[5];
		s[0]=new Student1("ravi");
		s[1]=new Student1("raju");
		
	s[2]=new Student1("rani");
	s[3]=new Employee(101,"Ramesh");
	
	}

}
