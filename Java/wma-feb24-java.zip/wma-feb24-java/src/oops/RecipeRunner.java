package oops;

public class RecipeRunner {

	public static void main(String[] args) {
		MicrowaveCurryRecipe microwaveCurryRecipe=new MicrowaveCurryRecipe();
		microwaveCurryRecipe.excecut();
		CurryRecipe curryRecipe=new CurryRecipe();
		curryRecipe.excecut();

	}

}
