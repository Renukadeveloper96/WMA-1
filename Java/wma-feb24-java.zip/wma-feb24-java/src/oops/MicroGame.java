package oops;

public class MicroGame implements GamingConsole{

	@Override
	public void up() {
		System.out.println("Microgame up");
		
	}

	@Override
	public void down() {
		System.out.println("Microgame down");
		
	}



}
