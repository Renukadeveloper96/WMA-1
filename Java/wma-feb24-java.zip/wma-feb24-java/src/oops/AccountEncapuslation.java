package oops;

public class AccountEncapuslation {

	private double balance=70000;

	public double getBalance() {//withdraw
		return balance;
	}

	public void setBalance(double balance) {//deposit
		this.balance = balance;
	}
	

}
