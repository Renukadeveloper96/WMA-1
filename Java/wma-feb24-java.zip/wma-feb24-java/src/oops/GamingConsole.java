package oops;

public interface GamingConsole {

	public void up();
	public void down();
	
}
