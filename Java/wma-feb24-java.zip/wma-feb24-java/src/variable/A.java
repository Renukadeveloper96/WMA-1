package variable;

public class A {

	
	static int m=100;
	int method() {
		return 90;
	}
	
	
	public static void main(String[] args) {
		int data=50;//instance variable
		A a=new A();
		System.out.println(m);
		
	}

}
