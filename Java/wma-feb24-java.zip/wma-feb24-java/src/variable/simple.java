package variable;

public class simple {

	public static void main(String[] args) {
	String a="welcome";
	String b=" to java";
	String c=a+b;
	System.out.println(c);
	
	}

}
