package variable;

public class B extends A{

	public static void main(String[] args) {
		
		A a=new A();
		System.out.println(a.method());
		System.out.println(m);	
	}

}
